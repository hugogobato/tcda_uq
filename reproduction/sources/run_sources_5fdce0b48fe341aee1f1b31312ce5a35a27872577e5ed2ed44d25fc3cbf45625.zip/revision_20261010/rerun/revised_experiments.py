"""Target-matched reruns for the 2026-10-10 revision.

Records are replication-level diagnostics. Small smoke runs are not evidence of
coverage. Uses iid covariates, independent folds, known or learned propensity,
training-only constant modulation, Bonferroni arm composition, and explicit
target-population sampling. Topological outcomes use plain tents, removing
GUDHI 3.11's sqrt(2) scaling. No legacy artifacts are overwritten.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import sys
import time

for _name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[_name] = "1"
os.environ.setdefault("MPLCONFIGDIR", "/tmp/cp_tate_matplotlib")
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))

import numpy as np
import pandas as pd
from scipy.special import expit
from sklearn.base import BaseEstimator, ClassifierMixin, clone
from sklearn.model_selection import KFold
from sklearn.linear_model import LogisticRegression
from tcda_uq.datasets import TriOracleSimulation, TopologicalCausalSimulation
from tcda_uq.estimators import cross_fit, CTATEDRLearner
from tcda_uq.estimators.nuisance import CrossFitResult
from tcda_uq.estimators.ctate_dr_learner import _fourier_design
from tcda_uq.estimators.aipw import aipw_scores
from tcda_uq.uq.asymptotic import multiplier_bootstrap_bands, ctate_confidence_band
from tcda_uq.uq.conformal.weighted_cp import weighted_conformal_radius


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def atomic_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(obj, indent=2, allow_nan=True) + "\n")
    temporary.replace(path)


def source_metadata():
    files = [*sorted(HERE.glob("*.py")), *sorted((ROOT / "tcda_uq").rglob("*.py"))]
    extra = ROOT / "experiments" / "pacce_simulation.py"
    if extra.exists():
        files.append(extra)
    return {"source_sha256": {str(p.relative_to(ROOT)): sha(p) for p in files},
            "versions": {p: importlib.metadata.version(p) for p in
                         ("numpy", "scipy", "scikit-learn", "gudhi", "scikit-fda", "pandas")},
            "python": sys.version, "outcome_scale": "plain normalized tents (legacy GUDHI/sqrt(2))"}


def iid_x(sim, n, rng):
    component = rng.integers(0, 2, n)
    means = np.where(component[:, None] == 0, sim.mu1, sim.mu2)
    return means + rng.multivariate_normal(np.zeros(sim.n_cov), sim.Sigma, n)


class KnownPropensity(ClassifierMixin, BaseEstimator):
    def __init__(self, kind="functional", scale=1.0, selected=False):
        self.kind, self.scale, self.selected = kind, scale, selected

    def fit(self, X, y):
        self.classes_ = np.array([0, 1])
        return self

    def probability(self, X):
        X = np.atleast_2d(X)
        if self.kind=="bounded":
            return .25+.5*expit(X[:,0])
        if self.kind == "pacce":
            if self.selected:
                burden = (X[:, 4] - 3.0) / 2.0
                q0 = np.clip(0.75 - 0.05 * burden, 0, 1)
                q1 = np.clip(0.55 - 0.08 * burden, 0, 1)
                return q1 / (q0 + q1)
            return np.full(len(X), 0.5)
        beta = np.array([-0.5, -0.1, 0.6, 0.1, 0.1])[:X.shape[1]]
        logit = X @ beta + 0.5 * X[:, 1] * X[:, 2] - 0.7 * X[:, 0] * X[:, 2]
        # Bound is part of the NEW DGP, rather than clipping an exact ratio.
        return np.clip(expit(self.scale * logit), 0.01, 0.99)

    def predict_proba(self, X):
        pi = self.probability(X)
        return np.column_stack([1 - pi, pi])


def interaction_features(X):
    X = np.atleast_2d(X)
    return np.column_stack([X, X[:, 1] * X[:, 2], X[:, 0] * X[:, 2]])


def fit_functional_regression(sample, tseq, n_basis=5, bound_coefficients=False):
    """Explicit least-squares Fourier projection, robust to redundant dummies.

    A missing training arm gets the deterministic zero center. Calibration
    still gives infinite radii when its arm has no observations.
    """
    phi, A, X = sample
    B = _fourier_design(tseq, n_basis)
    Z = np.column_stack([np.ones(len(X)), X])
    result = []
    for d in range(phi.shape[1]):
        arms = []
        for a in (0, 1):
            mask = A == a
            gamma = np.linalg.pinv(Z[mask]) @ (phi[mask, d] @ np.linalg.pinv(B).T) if mask.any() else np.zeros((Z.shape[1], n_basis))
            if bound_coefficients:
                # In the bounded benchmark the true coefficients lie strictly
                # inside this box. This supplies deterministic fitted-path
                # bounds even on nearly singular finite-sample designs.
                gamma = np.clip(gamma, -2.0, 2.0)
            arms.append(gamma)
        result.append((B, arms))
    return result


def predict_functional_regression(reg, X, tseq):
    Z = np.column_stack([np.ones(len(X)), X])
    return [(Z @ arms[0] @ B.T, Z @ arms[1] @ B.T) for B, arms in reg]


def stable_cross_fit(sample, tseq, propensity_estimator, random_state):
    phi, A, X = sample
    scores = [np.empty((len(A), phi.shape[-1])) for _ in range(phi.shape[1])]
    pi_all = np.empty(len(A))
    for train, test in KFold(2, shuffle=True, random_state=random_state).split(X):
        reg = fit_functional_regression((phi[train], A[train], X[train]), tseq,
                bound_coefficients=isinstance(propensity_estimator, KnownPropensity)
                                   and propensity_estimator.kind == "bounded")
        if len(np.unique(A[train])) < 2 and not isinstance(propensity_estimator, KnownPropensity):
            pi = np.full(len(test), .5)
        else:
            prop = clone(propensity_estimator).fit(X[train], A[train])
            pi = prop.predict_proba(X[test])[:, 1]
        pi_all[test] = pi
        values = aipw_scores(pi, predict_functional_regression(reg, X[test], tseq), (phi[test], A[test], X[test]))
        for d in range(phi.shape[1]): scores[d][test] = values[d]
    means = [s.mean(0) for s in scores]
    return CrossFitResult(np.asarray(tseq), means, means, means, scores, pi_all, np.arange(len(A)))


def generate(cfg, n, seed):
    rng = np.random.default_rng(seed)
    kind = cfg["kind"]
    if kind=="bounded":
        X=rng.uniform(-1,1,(n,3))
        # D={(0,2),(1,3)} has equal-weight plain silhouette identically .5
        # over [1.1,1.9]; an empty diagram has silhouette zero.
        t=np.linspace(1.1,1.9,cfg["resolution"])
        q0=.3+.1*X[:,0];q1=.6+.1*X[:,1]
        values=np.stack([rng.binomial(1,q0),rng.binomial(1,q1)],1)*.5
        po=np.tile(values[:,:,None,None],(1,1,1,len(t)))
        pi=KnownPropensity(kind="bounded").probability(X)
        return X,rng.binomial(1,pi),po,pi,t
    if kind == "functional":
        sim = TriOracleSimulation(n_hom_dim=cfg["degrees"], resolution=cfg["resolution"],
                                  n_basis=5, noise_scale=0.3, seed=0)
        X = iid_x(sim, n, rng)
        po = np.stack([sim._mean(a, X) + sim._noise(n, rng, X) for a in (0, 1)], axis=1)
        if cfg["scenario"] == "step":
            po[:, 1] += (X[:, 0] > 0.7)[:, None, None] * np.sin(np.pi * sim.tseq)[None, None, :]
        model = KnownPropensity(scale=cfg["scale"])
        pi = model.probability(X)
        return X, rng.binomial(1, pi), po, pi, sim.tseq
    if kind == "topological":
        sim = TopologicalCausalSimulation(n_cov=3, homology_dims=tuple(range(cfg["degrees"])),
                                         resolution=cfg["resolution"], r=cfg["r"],
                                         pts_per_loop=cfg["points"], background=6, seed=0)
        X = iid_x(sim, n, rng)
        po = np.stack([sim.sample_potential_outcome(X, a, rng) for a in (0, 1)], axis=1) / np.sqrt(2)
        model = KnownPropensity(kind="topological", scale=cfg["scale"])
        pi = model.probability(X)
        return X, rng.binomial(1, pi), po, pi, sim.tseq
    if kind == "orbit":
        from tcda_uq.datasets.orbit import make_orbit_causal
        sim = TriOracleSimulation(resolution=cfg["resolution"])
        X = iid_x(sim, n, rng)
        data = make_orbit_causal(n=n, num_pts=cfg["points"], r=cfg["r"],
                                resolution=cfg["resolution"], rng=rng)
        pi = KnownPropensity(scale=cfg["scale"]).probability(X)
        return X, rng.binomial(1, pi), data["potential_outcomes"] / np.sqrt(2), pi, data["tseq"]
    if kind == "sars":
        pools = np.load(cfg["pool"])
        sim = TriOracleSimulation(resolution=cfg["resolution"])
        X = iid_x(sim, n, rng)
        ctrl = pools["infected"][rng.integers(len(pools["infected"]), size=n)]
        chosen = rng.random(n) < 0.75
        trt = pools["infected"][rng.integers(len(pools["infected"]), size=n)].copy()
        trt[chosen] = pools["noninfected"][rng.integers(len(pools["noninfected"]), size=chosen.sum())]
        pi = KnownPropensity(scale=cfg["scale"]).probability(X)
        return X, rng.binomial(1, pi), np.stack([ctrl, trt], 1), pi, pools["tseq"]
    if kind == "pacce":
        from experiments.pacce_simulation import PacceSimulator, BASE_COLS
        # Representation constants supplied explicitly, never estimated from this sample.
        sim = PacceSimulator(cfg["scenario"], n=n, seed=seed,
                             std_consts=cfg["standardization"], resolution=cfg["resolution"])
        d = sim.one_draw()
        X, A, R = d["X"][BASE_COLS].to_numpy(float), d["A"].astype(int), d["R"]
        obs, delta = d["phi_obs"][:, 0] / np.sqrt(2), d["delta"] / np.sqrt(2)
        phi0 = obs - A[:, None] * delta
        po = np.stack([phi0[:, None], (phi0 + delta)[:, None]], 1)
        # Controlled simulation R depends only on A,X; causal interpretation
        # is justified HERE by the generator, never inferred for the clinical trial.
        pi = KnownPropensity(kind="pacce", selected=cfg["scenario"] == "dropout_arm").probability(X)
        return X[R], A[R], po[R], pi[R], np.linspace(0, 0.83, cfg["resolution"])
    raise ValueError(kind)


def draw_target(cfg, n, seed, target):
    rng = np.random.default_rng(seed)
    values = []
    count = 0
    while count < n:
        X, A, po, pi, t = generate(cfg, max(n, 64), int(rng.integers(2**31)))
        h = np.ones(len(X))
        if target == "overlap":
            h = 4 * pi * (1 - pi)
        elif target == "matching":
            h = 2 * np.minimum(pi, 1 - pi)
        elif target == "tilted":
            h = (4 * pi * (1 - pi)) ** 0.5
        accepted = rng.random(len(X)) < h
        values.append((X[accepted], po[accepted], pi[accepted]))
        count += int(accepted.sum())
    return np.concatenate([v[0] for v in values])[:n], np.concatenate([v[1] for v in values])[:n], np.concatenate([v[2] for v in values])[:n], t


def make_truth(cfg, out):
    path = out / "truth.npz"
    if path.exists():
        return path
    X, po, pi, t = draw_target(cfg, cfg["oracle_n"], cfg["seed"] + 700000, "full")
    delta = po[:, 1] - po[:, 0]
    mean = delta.mean(0)
    se = delta.std(0, ddof=1) / np.sqrt(len(delta))
    profiles = np.array([np.mean(X, 0), X[0], X[-1]])
    curves = []
    curve_se = []
    if cfg["kind"]=="bounded":
        mean=np.full((1,len(t)),.15);se=np.zeros_like(mean)
        profiles=np.array([[-1.,0.,1.],[0.,0.,0.],[1.,-1.,0.]])
        curves=np.tile((.15+.05*(profiles[:,1]-profiles[:,0]))[:,None,None],(1,1,len(t)))
        curve_se=np.zeros_like(curves)
    if cfg["kind"] == "functional":
        sim = TriOracleSimulation(n_hom_dim=cfg["degrees"], resolution=cfg["resolution"], seed=0)
        mean = sim.true_tate()
        se = np.zeros_like(mean)
        if cfg["scenario"] == "step":
            from scipy.stats import norm
            prob = np.mean([norm.sf((0.7 - mu[0]) / np.sqrt(0.5)) for mu in (sim.mu1, sim.mu2)])
            mean = mean + prob * np.sin(np.pi * t)
        profiles = np.stack([sim.mu1, sim.EX, sim.mu2])
        curves = sim.true_ctate(profiles)
        if cfg["scenario"] == "step":
            curves += (profiles[:, 0] > 0.7)[:, None, None] * np.sin(np.pi * t)
        curve_se = np.zeros_like(curves)
    elif cfg["kind"] == "sars":
        pools = np.load(cfg["pool"])
        mean = 0.75 * (pools["noninfected"].mean(0) - pools["infected"].mean(0))
        se = np.zeros_like(mean)
        curves = np.tile(mean, (len(profiles), 1, 1))
        curve_se = np.zeros_like(curves)
    elif cfg["kind"] == "orbit":
        curves = np.tile(mean, (len(profiles), 1, 1))
        curve_se = np.tile(se, (len(profiles), 1, 1))
    elif cfg["kind"] == "topological":
        sim = TopologicalCausalSimulation(n_cov=3, homology_dims=tuple(range(cfg["degrees"])),
                                         resolution=cfg["resolution"], r=cfg["r"],
                                         pts_per_loop=cfg["points"], background=6, seed=0)
        profile_rng = np.random.default_rng(cfg["seed"] + 800000)
        for profile in profiles:
            repeated = np.tile(profile, (cfg["profile_mc"], 1))
            dp = (sim.sample_potential_outcome(repeated,1,profile_rng) - sim.sample_potential_outcome(repeated,0,profile_rng)) / np.sqrt(2)
            curves.append(dp.mean(0))
            curve_se.append(dp.std(0,ddof=1)/np.sqrt(len(dp)))
    elif cfg["kind"] == "pacce":
        from experiments.pacce_simulation import PacceSimulator, PROFILES, BASE_COLS
        profiles = np.array([[v[c] for c in BASE_COLS] for v in PROFILES.values()])
        for j, profile in enumerate(PROFILES.values()):
            sim = PacceSimulator(cfg["scenario"], n=cfg["profile_mc"], seed=cfg["seed"] + 800000 + j,
                                 std_consts=cfg["standardization"], resolution=cfg["resolution"])
            d = sim.one_draw(override_row=profile)
            curves.append(d["delta"].mean(0)[None] / np.sqrt(2))
            curve_se.append(d["delta"].std(0,ddof=1)[None]/np.sqrt(2*len(d["delta"])))
    np.savez_compressed(path, mean=mean, oracle_se=se, profiles=profiles, ctate=curves, ctate_oracle_se=curve_se, tseq=t)
    atomic_json(out / "truth_metadata.json", {"oracle_n":len(delta), "seed":cfg["seed"] + 700000,
                                             "sup_oracle_se":float(se.max()),
                                             "sup_profile_oracle_se":float(np.max(curve_se)),
                                             "profile_mc":cfg["profile_mc"],
                                             "coverage_scope":"fixed finite grid; oracle approximation uncertainty must be assessed before inferential validation",
                                             "note":"Profile oracle SE stored in truth.npz; enlarge profile_mc and repeat truth checks when non-negligible relative to band widths."})
    return path


def fit_arm_models(sample, t, train, cal, cfg):
    phi, A, X = sample
    reg = fit_functional_regression((phi[train], A[train], X[train]), t, n_basis=5,
                                   bound_coefficients=cfg["kind"] == "bounded")
    if cfg["weights"] == "known":
        prop = KnownPropensity(cfg["kind"], cfg["scale"], cfg["scenario"] == "dropout_arm").fit(X[train], A[train])
        feat = lambda x: x
    else:
        feat = (lambda x: np.zeros((len(x), 1))) if cfg["weights"] == "misspecified" else interaction_features
        if len(np.unique(A[train]))<2:
            prop = KnownPropensity(kind="pacce").fit(X[train], A[train])
            feat = lambda x:x
        else:
            prop = LogisticRegression(max_iter=2000).fit(feat(X[train]), A[train])
    # Constant modulation is fixed before calibration and everywhere positive.
    mu = predict_functional_regression(reg, X[cal], t)
    pi_cal = prop.predict_proba(feat(X[cal]))[:, 1]
    return reg, prop, feat, mu, pi_cal


def conformal_events(sample, cfg, target, test, seed, po_training=None):
    phi, A, X = sample
    Xt, po, _, t = test
    rng = np.random.default_rng(seed)
    idx = rng.permutation(len(A))
    cal, train = np.sort(idx[:len(idx)//2]), np.sort(idx[len(idx)//2:])
    reg, prop, feat, mu, pc = fit_arm_models(sample, t, train, cal, cfg)
    mut = predict_functional_regression(reg, Xt, t)
    pt = prop.predict_proba(feat(Xt))[:, 1]
    def weight(pi, a):
        h = np.ones_like(pi)
        if target == "overlap": h = pi * (1 - pi)
        if target == "matching": h = np.minimum(pi, 1 - pi)
        if target == "tilted": h = np.sqrt(pi * (1 - pi))
        if target == "clip": pi = np.clip(pi, 0.1, 0.9)
        w = h / (pi if a == 1 else 1 - pi)
        if target == "shrink": w = w / (1 + w / 10)
        return w
    rows = []
    for scheme in ("joint", "bonferroni", "sidak_comparator"):
        arm_half, arm_events = [], []
        for a in (0, 1):
            mask = A[cal] == a
            residual = np.stack([phi[cal][mask, d] - mu[d][a][mask] for d in range(phi.shape[1])], 1)
            score = np.max(np.abs(residual), axis=2)
            beta = cfg["alpha_prediction"] / 2
            if scheme == "joint":
                k = weighted_conformal_radius(score.max(1), beta, weight(pc[mask], a), weight(pt, a)) if mask.any() else np.full(len(Xt),np.inf)
                half = np.tile(k[:, None], (1, phi.shape[1]))
            else:
                level = beta / phi.shape[1] if scheme == "bonferroni" else 1 - (1-beta)**(1/phi.shape[1])
                half = np.stack([weighted_conformal_radius(score[:, d], level, weight(pc[mask], a), weight(pt, a)) if mask.any() else np.full(len(Xt),np.inf) for d in range(phi.shape[1])], 1)
            center = np.stack([mut[d][a] for d in range(phi.shape[1])], 1)
            arm_half.append(half)
            arm_events.append((np.abs(po[:, a] - center) <= half[:, :, None]).all((1, 2)))
        center = np.stack([mut[d][1] - mut[d][0] for d in range(phi.shape[1])], 1)
        half = arm_half[0] + arm_half[1]
        delta = po[:, 1] - po[:, 0]
        finite = np.isfinite(half).all(1)
        covered = (np.abs(delta - center) <= half[:, :, None]).all((1, 2))
        # Direct delta score is a simulation-only reference, fitted from paired
        # training units. It never uses the clinical trial's missing counterfactuals.
        rows.append({"metric":"ITTE", "target":target, "scheme":scheme,
                     "coverage":float(covered.mean()), "finite_coverage":float(covered[finite].mean()) if finite.any() else None,
                     "finite_width":float((2*half[finite]).mean()) if finite.any() else None,
                     "unbounded_fraction":float((~finite).mean()),
                     "arm0_coverage":float(arm_events[0].mean()), "arm1_coverage":float(arm_events[1].mean()),
                     "arms_intersection":float((arm_events[0] & arm_events[1]).mean()),
                     "n_test":len(Xt), "n_cal_arm0":int((A[cal]==0).sum()), "n_cal_arm1":int((A[cal]==1).sum())})
    if po_training is not None:
        center_cal = np.stack([mu[d][1]-mu[d][0] for d in range(phi.shape[1])],1)
        delta_cal = po_training[cal,1]-po_training[cal,0]
        direct_score = np.max(np.abs(delta_cal-center_cal),(1,2))
        def tilt(pi):
            if target=="overlap": return pi*(1-pi)
            if target=="matching": return np.minimum(pi,1-pi)
            if target=="tilted": return np.sqrt(pi*(1-pi))
            return np.ones_like(pi)
        radius=weighted_conformal_radius(direct_score,cfg["alpha_prediction"],tilt(pc),tilt(pt))
        event=(np.abs(po[:,1]-po[:,0]-center)<=radius[:,None,None]).all((1,2))
        finite=np.isfinite(radius)
        rows.append({"metric":"ITTE","target":target,"scheme":"direct_oracle_comparator",
                     "coverage":float(event.mean()),"finite_width":float((2*radius[finite]).mean()) if finite.any() else None,
                     "unbounded_fraction":float((~finite).mean()),"n_test":len(Xt)})
    return rows


def one_rep(task):
    cfg, rep, out = task
    started = time.monotonic()
    seed = cfg["seed"] + rep * 100003
    path = Path(out) / f"rep_{rep:06d}.json"
    if path.exists():
        return {"rep":rep, "resumed":True}
    try:
        X, A, po, pi, t = generate(cfg, cfg["n"], seed)
        sample = (po[np.arange(len(A)), A], A, X)
        truth = np.load(Path(out) / "truth.npz")
        known = KnownPropensity(cfg["kind"], cfg["scale"], cfg["scenario"] == "dropout_arm")
        cf = stable_cross_fit(sample, t, propensity_estimator=known, random_state=seed + 1)
        bands = multiplier_bootstrap_bands(cf, alpha=cfg["alpha_confidence"], n_boot=cfg["n_boot"], rng=seed + 2, multiplier="gaussian", standardize=False)
        rows = []
        for d, band in enumerate(bands):
            rows.append({"metric":"TATE", "target":"selected" if cfg["kind"] == "pacce" else "full",
                         "degree":d, "coverage":float(((truth["mean"][d]>=band.lower)&(truth["mean"][d]<=band.upper)).all()),
                         "width":float((band.upper-band.lower).mean()),
                         "sup_bias":float(np.max(np.abs(band.center-truth["mean"][d]))),
                         "mean_error":float(np.mean(band.center-truth["mean"][d])),
                         "mean_estimated_se":float(np.sqrt(np.var(cf.scores[d],0,ddof=1)/len(A)).mean())})
        learner = CTATEDRLearner(n_basis=5).fit(sample,t,cross_fit_result=cf)
        for j, x in enumerate(truth["profiles"]):
            for d in range(po.shape[2]):
                band = ctate_confidence_band(learner,x,d,alpha=cfg["alpha_confidence"],n_boot=cfg["n_boot"],rng=seed+100+j,multiplier="gaussian",standardize=False)
                cur = truth["ctate"][j,d]
                rows.append({"metric":"CTATE", "target":"fixed_profile", "profile":j, "degree":d,
                             "coverage":float(((cur>=band.lower)&(cur<=band.upper)).all()),
                             "width":float((band.upper-band.lower).mean()),
                             "sup_bias":float(np.max(np.abs(band.center-cur)))})
        for j, target in enumerate(cfg["targets"]):
            test = draw_target(cfg,cfg["m_test"],seed+1000+j*10000,target if target not in ("clip","shrink") else "full")
            rows.extend(conformal_events(sample,cfg,target,test,seed+3000,po_training=po))
        atomic_json(path,{"rep":rep,"seed":seed,"n_observed":len(A),"elapsed_seconds":time.monotonic()-started,"rows":rows})
        return {"rep":rep,"seconds":round(time.monotonic()-started,2)}
    except Exception as exc:
        atomic_json(Path(out)/f"failure_{rep:06d}.json",{"rep":rep,"error":f"{type(exc).__name__}: {exc}"})
        return {"rep":rep,"error":str(exc)}


def aggregate(out):
    records = []
    for p in sorted(Path(out).glob("rep_*.json")):
        obj = json.loads(p.read_text())
        for row in obj["rows"]:
            records.append({"rep":obj["rep"], **row})
    if not records:
        return
    df = pd.DataFrame(records)
    df.to_csv(Path(out)/"replication_records.csv",index=False)
    keys = [k for k in ("metric","target","scheme","degree","profile") if k in df]
    report = []
    for key, g in df.groupby(keys,dropna=False):
        row = dict(zip(keys,key))
        row["completed_replications"] = len(g)
        for column in ("coverage","finite_coverage","finite_width","width","unbounded_fraction","sup_bias","mean_error","mean_estimated_se","arm0_coverage","arm1_coverage","arms_intersection"):
            if column in g:
                value = g[column].dropna()
                row[column] = float(value.mean()) if len(value) else None
                row[column+"_mcse"] = float(value.std(ddof=1)/np.sqrt(len(value))) if len(value)>1 else None
                if column=="mean_error": row["empirical_sd_grid_mean_error"] = float(value.std(ddof=1)) if len(value)>1 else None
        report.append(row)
    pd.DataFrame(report).to_csv(Path(out)/"summary.csv",index=False)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--kind",choices=["bounded","functional","topological","orbit","sars","pacce"],default="functional")
    ap.add_argument("--scenario",default="base")
    ap.add_argument("--n",type=int,default=500)
    ap.add_argument("--reps",type=int,default=200)
    ap.add_argument("--m-test",type=int,default=200)
    ap.add_argument("--resolution",type=int,default=50)
    ap.add_argument("--n-boot",type=int,default=999)
    ap.add_argument("--oracle-n",type=int,default=6000)
    ap.add_argument("--profile-mc",type=int,default=800)
    ap.add_argument("--degrees",type=int,default=2)
    ap.add_argument("--scale",type=float,default=1)
    ap.add_argument("--r",type=float,default=3)
    ap.add_argument("--points",type=int,default=40)
    ap.add_argument("--weights",choices=["known","learned","misspecified"],default="known")
    ap.add_argument("--targets",nargs="+",choices=["full","overlap","matching","tilted","clip","shrink"],default=["full","overlap","matching"])
    ap.add_argument("--alpha-confidence",type=float,default=0.10)
    ap.add_argument("--alpha-prediction",type=float,default=0.05)
    ap.add_argument("--pool",type=str)
    ap.add_argument("--standardization",type=Path,default=ROOT/"results/pacce/pacce_smoke.json")
    ap.add_argument("--workers",type=int,default=1)
    ap.add_argument("--shard-id",type=int,default=0)
    ap.add_argument("--num-shards",type=int,default=1)
    ap.add_argument("--hours",type=float,default=9)
    ap.add_argument("--seed",type=int,default=20261010)
    ap.add_argument("--out",type=Path,required=True)
    args = ap.parse_args()
    if args.n < 4 or args.reps < 1 or args.m_test < 1 or args.resolution < 5 or args.n_boot < 1:
        ap.error("require n>=4, reps>=1, m-test>=1, resolution>=5 and n-boot>=1")
    if args.oracle_n < 2 or args.profile_mc < 2 or args.degrees < 1 or args.points < 3 or args.scale <= 0:
        ap.error("require oracle-n/profile-mc>=2, degrees>=1, points>=3 and scale>0")
    if not 0<=args.shard_id<args.num_shards: ap.error("invalid shard")
    if not 0<args.hours<=9.5: ap.error("hours must be in (0,9.5]")
    if args.r<1: ap.error("revised framework requires r>=1")
    if args.workers<1 or args.workers>4: ap.error("use 1-4 workers; assess available RAM/CPU first")
    if args.degrees>2 and args.kind!="functional": ap.error("topology generators support degrees 0,1 only")
    cfg = vars(args).copy()
    cfg["confidence_calibration"]="Gaussian, unstudentized supremum on fixed grid"
    for k in ("out","standardization"): cfg[k]=str(cfg[k])
    if args.kind=="pacce":
        cfg["degrees"]=1
        cfg["standardization"]=json.loads(args.standardization.read_text())["standardization"]
        if args.scenario=="base": cfg["scenario"]="null"
    if args.kind=="bounded":
        cfg["degrees"]=1
        cfg["nuisance_coefficient_box"]=[-2.0,2.0]
    if args.kind=="sars":
        cfg["degrees"]=1
        if not args.pool: ap.error("sars requires a preprocessed --pool")
        cfg["pool_sha256"]=sha(args.pool)
    args.out.mkdir(parents=True,exist_ok=True)
    manifest={"configuration":cfg,**source_metadata()}
    path=args.out/"manifest.json"
    if path.exists():
        old=json.loads(path.read_text())
        # Shard execution resources may differ; scientific settings must match.
        ignored=("shard_id","num_shards","workers","hours","out")
        if {k:v for k,v in old["configuration"].items() if k not in ignored}!={k:v for k,v in cfg.items() if k not in ignored} or old["source_sha256"]!=manifest["source_sha256"]:
            raise ValueError("resume configuration/source mismatch; choose a new output directory")
    else: atomic_json(path,manifest)
    started=time.monotonic()
    make_truth(cfg,args.out)
    ids=[i for i in range(args.reps) if i%args.num_shards==args.shard_id and not (args.out/f"rep_{i:06d}.json").exists()]
    # Submit at most workers replications per batch so the deadline does not
    # leave a large backlog. Each completed replication checkpoints atomically.
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for offset in range(0,len(ids),args.workers):
            if time.monotonic()-started>args.hours*3600: break
            tasks=[(cfg,i,str(args.out)) for i in ids[offset:offset+args.workers]]
            for result in pool.map(one_rep,tasks): print(json.dumps(result),flush=True)
    aggregate(args.out)
    print(f"Completed {len(list(args.out.glob('rep_*.json')))} of {args.reps} requested replications. Failures remain separate; rerun to resume.",flush=True)


if __name__=="__main__": main()
