"""Merge independent downloaded shard directories without double-counting."""
import argparse,json,shutil
from pathlib import Path
from revised_experiments import aggregate,atomic_json

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("inputs",nargs="+",type=Path)
    ap.add_argument("--out",type=Path,required=True)
    a=ap.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    manifest=None;truth_bytes=None;failure_records=[]
    ignored={"out","shard_id","num_shards","workers","hours"}
    for input_id,folder in enumerate(a.inputs):
        m=json.loads((folder/"manifest.json").read_text())
        key={"source_sha256":m["source_sha256"],"versions":m["versions"],"python":m["python"],"configuration":{k:v for k,v in m["configuration"].items() if k not in ignored}}
        if manifest is not None and key!=manifest:raise ValueError("incompatible shard source/configuration")
        manifest=key
        truth=(folder/"truth.npz").read_bytes()
        if truth_bytes is not None:
            # Zip containers can differ in metadata; compare numerical truth arrays.
            import numpy as np
            left=np.load(a.out/"truth.npz");right=np.load(folder/"truth.npz")
            if set(left.files)!=set(right.files) or any(not np.array_equal(left[k],right[k],equal_nan=True) for k in left.files):raise ValueError("incompatible oracle truths")
        else:
            truth_bytes=truth
            shutil.copy2(folder/"truth.npz",a.out/"truth.npz")
            shutil.copy2(folder/"manifest.json",a.out/"manifest.json")
            shutil.copy2(folder/"truth_metadata.json",a.out/"truth_metadata.json")
        for p in folder.glob("rep_*.json"):
            q=a.out/p.name
            if q.exists() and json.loads(q.read_text())!=json.loads(p.read_text()):raise ValueError(f"conflicting duplicate replication {p.name}")
            if not q.exists():shutil.copy2(p,q)
        # Retain attempts even if a later resume eventually completed that ID.
        # Distinct source-shard directories prevent failure names colliding.
        shard=m["configuration"].get("shard_id",0)
        count=m["configuration"].get("num_shards",1)
        destination=a.out/"failures"/f"input_{input_id:03d}_shard_{shard:03d}_of_{count:03d}"
        destination.mkdir(parents=True,exist_ok=True)
        shutil.copy2(folder/"manifest.json",destination/"manifest.json")
        for p in sorted(folder.glob("failure_*.json")):
            shutil.copy2(p,destination/p.name)
            failure_records.append({"input":str(folder),"artifact":str((destination/p.name).relative_to(a.out)),**json.loads(p.read_text())})
    aggregate(a.out)
    completed={json.loads(p.read_text())["rep"] for p in a.out.glob("rep_*.json")}
    failed_ids={r["rep"] for r in failure_records}
    atomic_json(a.out/"failure_summary.json",{"failure_artifacts":len(failure_records),"distinct_replications_with_recorded_failure":len(failed_ids),"unresolved_replication_ids":sorted(failed_ids-completed),"records":failure_records})
    atomic_json(a.out/"merge_provenance.json",{"inputs":[str(p) for p in a.inputs],"replications":len(completed),"failure_artifacts":len(failure_records),"unresolved_replications":len(failed_ids-completed)})
    print("Merged",len(list(a.out.glob('rep_*.json'))),"independent replications")

if __name__=="__main__":main()
