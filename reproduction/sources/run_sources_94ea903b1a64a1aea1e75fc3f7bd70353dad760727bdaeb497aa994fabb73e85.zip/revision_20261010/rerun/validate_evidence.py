"""Read-only numerical/visual audit of existing artifacts; writes new audit outputs."""
from pathlib import Path
import json,re,hashlib,sys,os
os.environ.setdefault("MPLCONFIGDIR","/tmp/cp_tate_matplotlib")
ROOT=Path(__file__).resolve().parents[2]
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def weighted_rows(paths,ctate=False):
    rows=[]
    for path in paths:
        txt=path.read_text()
        header=txt.splitlines()[0]
        m=re.search(r"reps=(\d+)/(\d+)",header)
        if not m:continue
        reps=int(m[1])
        for line in txt.splitlines():
            tok=line.split()
            if not tok or not tok[0].isdigit():continue
            if ctate and len(tok)==8:
                n,x,method,d=tok[:4]; val=tok[4:];cov,width=float(val[1]),float(val[3])
            elif not ctate and len(tok)==6:
                n,method,d=tok[:3];x="";cov,width=float(tok[3]),float(tok[5])
            else:continue
            successes=round(cov*reps)
            if abs(successes/reps-cov)>.00051:raise ValueError("cannot recover rounded Bernoulli count")
            rows.append(dict(n=int(n),profile=x,method=method,degree=int(d),reps=reps,successes=successes,width_sum=width*reps))
    frame=pd.DataFrame(rows)
    groups=frame.groupby(["n","profile","method","degree"])[["reps","successes","width_sum"]].sum().reset_index()
    groups["coverage"]=groups.successes/groups.reps
    groups["coverage_mcse"]=np.sqrt(groups.coverage*(1-groups.coverage)/groups.reps)
    groups["width"]=groups.width_sum/groups.reps
    return groups

def main():
    out=ROOT/"revision_20261010/audit"
    out.mkdir(exist_ok=True)
    tate=weighted_rows(sorted((ROOT/"experiments/out/phase7").glob("phase2_shard*.txt")))
    ctate=weighted_rows(sorted((ROOT/"experiments/out/phase3").glob("shard*.txt")),True)
    tate.to_csv(out/"verified_tate_aggregate.csv",index=False)
    ctate.to_csv(out/"verified_ctate_aggregate.csv",index=False)
    findings={"TATE_replications":sorted(tate.reps.unique().tolist()),"CTATE_replications":sorted(ctate.reps.unique().tolist()),
              "aggregation_note":"Unequal seven-shard means must be replication weighted; Bernoulli counts recovered from three-decimal shard proportions.","figures":{}}
    p=ROOT/"results/pacce/tate_estimates.parquet"
    curve=pd.read_parquet(p)
    findings["pacce_tate"]={"n_grid":len(curve),"peak_abs":float(curve.psi_hat.abs().max()),"peak_t":float(curve.loc[curve.psi_hat.abs().idxmax(),"tseq"]),
                             "mean_width":float((curve.upper-curve.lower).mean()),"zero_excluded_fraction":float(((curve.lower>0)|(curve.upper<0)).mean()),
                             "sha256":hashlib.sha256(p.read_bytes()).hexdigest()}
    # Expose the convention and adjusted selected-cohort scope in regenerated visuals.
    figdir=ROOT/"revision_20261010/revised/figures"
    fig,ax=plt.subplots(figsize=(7,3.7))
    ax.fill_between(curve.tseq,curve.lower,curve.upper,color="#4477AA",alpha=.25,label="Nominal 90% gridwise band")
    ax.plot(curve.tseq,curve.psi_hat,color="#4477AA",label="Adjusted observed-group contrast")
    ax.axhline(0,color=".3",lw=.8)
    ax.set(xlabel="Filtration radius",ylabel="Legacy silhouette units ($\\sqrt{2}\\,\\phi_0$)")
    ax.legend(frameon=False,fontsize=8)
    fig.tight_layout()
    fig.savefig(figdir/"pacce_selected_contrast.pdf")
    fig.savefig(out/"pacce_selected_contrast.png",dpi=140)
    plt.close(fig)
    c=pd.read_parquet(ROOT/"results/pacce/ctate_curves.parquet")
    summary=pd.read_csv(ROOT/"results/pacce/ctate_itte_results_summary.csv")
    check=[]
    for name,g in c.groupby("profile",sort=False):
        check.append(dict(profile=name,peak=float(g.center.abs().max()),width=float((g.upper-g.lower).mean()),exc=float(((g.lower>0)|(g.upper<0)).mean())))
    checked=pd.DataFrame(check).merge(summary,on="profile")
    assert np.allclose(checked.peak,checked.peak_abs_tau)
    assert np.allclose(checked.width,checked.mean_halfwidth*2)
    assert np.allclose(checked.exc,checked.excursion_frac)
    findings["profile_validation"]="CSV peaks, widths, exclusion fractions equal full curve parquet values. n_matching is exact backbone and burden, not bin cell membership."
    placebo=pd.read_csv(ROOT/"results/pacce/placebo_checks.csv")
    perms=placebo[placebo.tag.str.startswith("perm_")]
    findings["placebo"]={"replications":len(perms),"rejects":int(perms.reject.sum()),"rate":float(perms.reject.mean()),"mcse":float(np.sqrt(perms.reject.mean()*(1-perms.reject.mean())/len(perms)))}
    findings["legacy_benchmark_conflict"]="on-study response old tex 0.559/0.442; originating CSV 0.44418/0.43705. Use CSV or omit."
    findings["legacy_missingness_conflicts"]="opposite assigned-arm sign; n_weighted reference=2*n_arm1=556 rather than total566; reference is unadjusted contrast, not AIPW; baseline odds tilt is not an identified MNAR sensitivity model."
    (out/"numerical_visual_validation.json").write_text(json.dumps(findings,indent=2)+"\n")
    print(json.dumps(findings,indent=2))

if __name__=="__main__":main()
