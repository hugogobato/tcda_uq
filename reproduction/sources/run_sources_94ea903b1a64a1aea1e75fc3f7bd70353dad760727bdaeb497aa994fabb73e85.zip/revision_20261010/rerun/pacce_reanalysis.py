"""Frozen-pilot selected-cohort PACCE diagnostics, never a causal-ID repair.

Reserve pilot patients before estimating coordinate scales. Hold these scales,
grid, degree and exponent fixed on the remaining subjects. Estimate an adjusted
observed-group contrast with a full-baseline selected-cohort propensity. Report
fixed-profile smoother diagnostics and training-only-modulation prediction
objects. No patient counterfactual coverage or exact conformal claim is made.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import sys
import time
for name in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[name]="1"
os.environ.setdefault("MPLCONFIGDIR","/tmp/cp_tate_matplotlib")
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT))
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from tcda_uq.datasets.pacce import (SPEC_V1,BASELINE_COLS,DEMO_REQUIRED,LESION_REQUIRED,
    load_pacce_from_frames,subject_clouds,window_records,build_baseline_X)
from tcda_uq.estimators import cross_fit,CTATEDRLearner
from tcda_uq.uq.asymptotic import multiplier_bootstrap_bands,ctate_confidence_band
from revised_experiments import (atomic_json,source_metadata,stable_cross_fit,
    fit_functional_regression,predict_functional_regression)
from tcda_uq.uq.conformal.weighted_cp import weighted_conformal_radius


def run(demo,lesion,args):
    rng=np.random.default_rng(args.seed)
    ids=np.sort(demo.SUBJID.astype(int).unique())
    pilot=np.sort(rng.choice(ids,size=max(10,int(len(ids)*args.pilot_fraction)),replace=False))
    analysis=np.setdiff1d(ids,pilot)
    spec=copy.deepcopy(SPEC_V1)
    # Pilot scale is fitted only from pilot subjects, including their observed
    # week-12 records. Hence the scientific target is pilot-conditional, and
    # the pilot never appears in training, calibration, or inference.
    clouds,_,_=subject_clouds(window_records(lesion[lesion.SUBJID.astype(int).isin(pilot)],spec),spec)
    if not clouds: raise ValueError("no eligible pilot subjects")
    pooled=np.concatenate(list(clouds.values()))
    spec["standardization"]={"mean":pooled.mean(0).tolist(),"sd":pooled.std(0).tolist()}
    spec["silhouette"]={"r":args.r,"resolution":args.resolution,"interval":[0.0,args.grid_max]}
    selected=load_pacce_from_frames(demo[demo.SUBJID.astype(int).isin(analysis)],
                                    lesion[lesion.SUBJID.astype(int).isin(analysis)],spec)
    phi=selected.phi[:,[0]]/np.sqrt(2)
    X=selected.X[BASELINE_COLS].to_numpy(float)
    A=selected.A.astype(int)
    if not np.isfinite(X).all(): raise ValueError("baseline covariates contain missing numerical values; prespecify imputation")
    cf=stable_cross_fit((phi,A,X),selected.tseq,
                       propensity_estimator=LogisticRegression(max_iter=2000),random_state=args.seed)
    band=multiplier_bootstrap_bands(cf,alpha=.1,n_boot=args.n_boot,rng=args.seed+1,multiplier="gaussian",standardize=False)[0]
    pd.DataFrame(dict(t=selected.tseq,estimate=band.center,lower=band.lower,upper=band.upper)).to_csv(args.out/"adjusted_selected_contrast.csv",index=False)
    learner=CTATEDRLearner(n_basis=args.stage2_basis).fit((phi,A,X),selected.tseq,cross_fit_result=cf)
    profiles=[]
    profile_rows=[]
    for backbone in (0,1):
        for burden in (2,4,6):
            profile=np.median(X,0)
            profile[0]=backbone
            profile[4]=burden
            cb=ctate_confidence_band(learner,profile,0,alpha=.1,n_boot=args.n_boot,rng=args.seed+backbone*100+burden,multiplier="gaussian",standardize=False)
            profile_rows.append(profile)
            profiles.append(dict(backbone=backbone,burden=burden,
                exact_matching=int(((X[:,0]==backbone)&(X[:,4]==burden)).sum()),
                bin_matching=int(((X[:,0]==backbone)&((X[:,4]<=2) if burden==2 else ((X[:,4]>=3)&(X[:,4]<=4)) if burden==4 else X[:,4]>=5)).sum()),
                peak_abs_estimate=float(np.abs(cb.center).max()),width=float((cb.upper-cb.lower).mean()),
                zero_excluded_fraction=float(((cb.lower>0)|(cb.upper<0)).mean())))
    pd.DataFrame(profiles).to_csv(args.out/"fixed_profile_diagnostics.csv",index=False)
    # New prediction SHAPES only: observed data contain no paired individual
    # effects. No coverage indicator or artificial target is constructed.
    idx=rng.permutation(len(A));cal=idx[:len(idx)//2];train=idx[len(idx)//2:]
    reg=fit_functional_regression((phi[train],A[train],X[train]),selected.tseq)
    prop=LogisticRegression(max_iter=2000).fit(X[train],A[train])
    queried=np.stack(profile_rows)
    mus=predict_functional_regression(reg,X[cal],selected.tseq)[0]
    mut=predict_functional_regression(reg,queried,selected.tseq)[0]
    pc=prop.predict_proba(X[cal])[:,1];pt=prop.predict_proba(queried)[:,1]
    halves=[]
    for arm in (0,1):
        mask=A[cal]==arm
        scores=np.max(np.abs(phi[cal][mask,0]-mus[arm][mask]),1)
        wc=1/(pc[mask] if arm else 1-pc[mask]);wt=1/(pt if arm else 1-pt)
        halves.append(weighted_conformal_radius(scores,.025,wc,wt) if mask.any() else np.full(len(queried),np.inf))
    prediction=[]
    for j,(x,summary) in enumerate(zip(queried,profiles)):
        center=mut[1][j]-mut[0][j];half=halves[0][j]+halves[1][j]
        for t,c in zip(selected.tseq,center):prediction.append(dict(backbone=summary["backbone"],burden=summary["burden"],t=t,center=c,lower=c-half,upper=c+half))
    pd.DataFrame(prediction).to_csv(args.out/"exploratory_prediction_shapes.csv",index=False)
    selected.manifest.to_csv(args.out/"analysis_manifest.csv",index=False)
    # Audit selection in the WHOLE analysis split. Explicit SUBJID joins and
    # assigned-arm signs prevent the legacy metadata/sign indexing defects.
    allx=build_baseline_X(demo[demo.SUBJID.astype(int).isin(analysis)]).set_index("SUBJID").loc[analysis]
    arma=demo.set_index(demo.SUBJID.astype(int)).loc[analysis].TRT.str.startswith("panit").astype(int).to_numpy()
    R=np.isin(analysis,selected.frame.SUBJID.astype(int)).astype(int)
    Z=np.column_stack([allx[BASELINE_COLS].to_numpy(float),arma])
    model=LogisticRegression(max_iter=4000).fit(Z,R)
    q=model.predict_proba(Z)[:,1]
    aligned=pd.DataFrame(phi[:,0],index=selected.frame.SUBJID.astype(int)).reindex(analysis).to_numpy()
    rows=[]
    burden=(Z[:,4]-Z[:,4].mean())/(Z[:,4].std()+1e-12)
    logit=model.decision_function(Z)
    for gamma in (-.75,-.5,-.25,0,.25,.5,.75):
        qt=np.clip(1/(1+np.exp(-(logit+gamma*burden))),.02,.98)
        means=[]
        for arm in (0,1):
            mask=(arma==arm)&(R==1)
            w=1/qt[mask]
            means.append(np.average(aligned[mask],axis=0,weights=w))
        rows.append(dict(gamma=gamma,n_eligible=int(R.sum()),n_released_analysis=len(R),
                         peak_abs_weighted_contrast=float(np.abs(means[1]-means[0]).max())))
    pd.DataFrame(rows).to_csv(args.out/"selection_weight_sensitivity.csv",index=False)
    atomic_json(args.out/"scope.json",{"pilot_ids":pilot.tolist(),"spec":selected.spec,
         "n_analysis_released":len(analysis),"n_analysis_eligible":len(A),"arm_counts":np.bincount(A).tolist(),
         "propensity_training":"learned full-baseline selected-cohort model; no exact randomized-ratio claim",
         "target":"adjusted observed-group contrast conditional on pilot representation and observed eligibility",
         "selection_sensitivity":"baseline observation-odds tilts; not MNAR identification and no bound for unobserved outcome/death",
         "causal_identification":"not asserted; requires additional selection and missing-outcome assumptions",
         "conformal":"excluded from causal validation; both potential outcomes unobserved jointly",
         "confidence_calibration":"Gaussian unstudentized fixed-grid supremum",
         "mean_width":float((band.upper-band.lower).mean()),"peak_abs_estimate":float(np.abs(band.center).max())})


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--sas-dir",type=Path)
    ap.add_argument("--fixture",action="store_true",help="nonclinical adapter smoke data")
    ap.add_argument("--pilot-fraction",type=float,default=.25)
    ap.add_argument("--seed",type=int,default=20261010)
    ap.add_argument("--r",type=float,default=3)
    ap.add_argument("--grid-max",type=float,default=1.0)
    ap.add_argument("--resolution",type=int,default=100)
    ap.add_argument("--n-boot",type=int,default=999)
    ap.add_argument("--stage2-basis",type=int,default=5)
    ap.add_argument("--out",type=Path,required=True)
    args=ap.parse_args()
    if not 0<args.pilot_fraction<.5: ap.error("pilot fraction must be in (0,.5)")
    if args.r<1: ap.error("r must be >=1")
    if args.grid_max <= 0 or args.resolution < 5 or args.n_boot < 1 or args.stage2_basis < 1:
        ap.error("require grid-max>0, resolution>=5, n-boot>=1, stage2-basis>=1")
    args.out.mkdir(parents=True,exist_ok=True)
    if args.fixture:
        from tcda_uq.datasets.pacce import synthetic_pacce_frames
        demo,lesion=synthetic_pacce_frames(n=120,seed=42)
        sources={"fixture":True,"warning":"Synthetic smoke data, never the PACCE trial."}
    else:
        if args.sas_dir is None: ap.error("provide --sas-dir or --fixture")
        import pyreadstat
        demo,_=pyreadstat.read_sas7bdat(str(args.sas_dir/"demo.sas7bdat"),usecols=DEMO_REQUIRED)
        lesion,_=pyreadstat.read_sas7bdat(str(args.sas_dir/"lesion.sas7bdat"),usecols=LESION_REQUIRED)
        sources={p:hashlib.sha256((args.sas_dir/p).read_bytes()).hexdigest() for p in ("demo.sas7bdat","lesion.sas7bdat")}
    atomic_json(args.out/"manifest.json",{**source_metadata(),"input_sha256":sources,"configuration":{k:str(v) if isinstance(v,Path) else v for k,v in vars(args).items()}})
    run(demo,lesion,args)


if __name__=="__main__":main()
