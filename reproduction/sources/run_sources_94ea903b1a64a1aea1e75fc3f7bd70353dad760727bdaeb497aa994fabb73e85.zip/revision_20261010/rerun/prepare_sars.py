"""Stream sorted CT slices to plain-tent H0 pools at r>=1; slice-pool target.

No patient-level inference: available filenames do not provide patient groups.
No resizing, masking, or cropping. Images use first channel /255, lower-star
cubical persistence, finite bars only, [0,1] grid, explicit exponent.
"""
import argparse,json,hashlib,os,sys
from pathlib import Path
for name in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS"):
    os.environ[name]="1"
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
import numpy as np
from PIL import Image
from tcda_uq.silhouette import silhouette_from_image

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--data-root",type=Path,required=True)
    ap.add_argument("--r",type=float,default=1)
    ap.add_argument("--resolution",type=int,default=50)
    ap.add_argument("--limit",type=int)
    ap.add_argument("--out",type=Path,required=True)
    a=ap.parse_args()
    if a.r<1:ap.error("r>=1 required")
    pools,manifest={},[]
    for label,key in (("COVID","infected"),("non-COVID","noninfected")):
        files=sorted(p for p in (a.data_root/label).iterdir() if p.suffix.lower() in (".png",".jpg",".jpeg"))
        if a.limit:files=files[:a.limit]
        values=[]
        for p in files:
            array=np.asarray(Image.open(p),dtype=float)/255
            if array.ndim==3:array=array[:,:,0]
            values.append(silhouette_from_image(array,(0,1),a.r,a.resolution,(0,))/np.sqrt(2))
            manifest.append({"file":str(p.relative_to(a.data_root)),"sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"shape":list(array.shape)})
        pools[key]=np.stack(values)
    a.out.parent.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(a.out,**pools,tseq=np.linspace(0,1,a.resolution))
    a.out.with_suffix(".json").write_text(json.dumps({"r":a.r,"scope":"empirical slice pools","plain_tents":True,"files":manifest},indent=2))

if __name__=="__main__":main()
