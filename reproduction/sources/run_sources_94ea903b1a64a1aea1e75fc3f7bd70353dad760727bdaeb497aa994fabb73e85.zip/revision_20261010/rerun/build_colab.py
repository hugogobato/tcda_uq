"""Build self-contained Colab notebooks with an embedded audited source bundle."""
import base64,hashlib,io,json,zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent

def cell(code,markdown=False):
    return {"cell_type":"markdown" if markdown else "code","metadata":{},"source":code.splitlines(keepends=True),**({} if markdown else {"execution_count":None,"outputs":[]})}

def notebook(name,description,cells):
    nb={"nbformat":4,"nbformat_minor":5,"metadata":{"kernelspec":{"display_name":"Python 3","language":"python","name":"python3"},"language_info":{"name":"python","version":"3.11"}},"cells":[cell(description,True),*cells]}
    for j,c in enumerate(nb["cells"]):c["id"]=f"cell-{j:03d}"
    (OUT/name).write_text(json.dumps(nb,indent=1)+"\n")

def main():
    source=[*sorted((ROOT/"tcda_uq").rglob("*.py")),*sorted(OUT.glob("*.py")),ROOT/"experiments/__init__.py",ROOT/"experiments/pacce_simulation.py",ROOT/"results/pacce/pacce_smoke.json",ROOT/"LICENSE",ROOT/"THIRD_PARTY_NOTICES.md"]
    buffer=io.BytesIO()
    with zipfile.ZipFile(buffer,"w",zipfile.ZIP_DEFLATED) as z:
        for p in source:z.writestr(str(p.relative_to(ROOT)),p.read_bytes())
    payload=buffer.getvalue();encoded=base64.b64encode(payload).decode()
    (OUT/"colab_source_bundle.zip").write_bytes(payload)
    setup=f'''# Source package is embedded; no repository clone or private service is required.
import base64, hashlib, io, os, sys, zipfile, subprocess
from pathlib import Path
payload = base64.b64decode({encoded!r})
assert hashlib.sha256(payload).hexdigest() == {hashlib.sha256(payload).hexdigest()!r}
WORK = Path('/content/cp_tate_revision') if Path('/content').exists() else Path.cwd() / 'colab_workspace'
WORK.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(io.BytesIO(payload)) as z:
    z.extractall(WORK)
subprocess.check_call([sys.executable, '-m', 'pip', 'install', '-q', 'numpy==2.0.2', 'scipy==1.15.2', 'scikit-learn==1.6.1', 'scikit-fda==0.10.1', 'gudhi==3.11.0', 'matplotlib==3.10.0', 'pandas==2.2.3', 'pyarrow', 'pyreadstat', 'pyyaml', 'pillow'])
os.chdir(WORK)
for variable in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[variable] = '1'
OUTPUT = WORK / 'outputs'
OUTPUT.mkdir(exist_ok=True)
print('Ready:', WORK)
'''
    resume='''# Optional: upload a previously downloaded output ZIP to resume.
RESUME = False
if RESUME:
    from google.colab import files
    uploaded = files.upload()
    for filename, content in uploaded.items():
        with zipfile.ZipFile(io.BytesIO(content)) as z:
            for item in z.infolist():
                target = (OUTPUT / item.filename).resolve()
                if OUTPUT.resolve() not in target.parents:
                    raise ValueError('Unsafe resume archive path')
            z.extractall(OUTPUT)
'''
    download='''# All outputs, manifests, failures and oracle arrays are retained in one ZIP.
import shutil
output_file = shutil.make_archive(str(WORK / 'revision_outputs'), 'zip', OUTPUT)
try:
    from google.colab import files
    files.download(output_file)
    print('Downloaded:', output_file)
except Exception as e:
    print('(Not on Colab / download skipped):', e)
'''
    control='''# Set SHARD_ID separately in each independent account; IDs 0,...,NUM_SHARDS-1.
# Run a smoke profile first. These settings are a production request, not completed evidence.
SHARD_ID, NUM_SHARDS = 0, 1  # Increase (up to 48) only after measured runtime justifies it.
KIND, SCENARIO = 'bounded', 'base'  # functional, topological, orbit, pacce also supported
N, REPS, RESOLUTION = 500, 200, 50
ORACLE_N, PROFILE_MC, POINTS = 500, 100, 40  # Pilot defaults; inspect oracle SE before enlarging.
WORKERS, HOURS = 2, 8.5  # 1 BLAS thread per worker; bounded process batches
TARGETS = ['full', 'overlap', 'matching']
WEIGHTS = 'known'  # learned or misspecified are explicitly empirical sensitivities
cmd = [sys.executable, 'revision_20261010/rerun/revised_experiments.py',
       '--kind', KIND, '--scenario', SCENARIO, '--n', str(N), '--reps', str(REPS),
       '--resolution', str(RESOLUTION), '--workers', str(WORKERS), '--hours', str(HOURS),
       '--oracle-n', str(ORACLE_N), '--profile-mc', str(PROFILE_MC), '--points', str(POINTS),
       '--weights', WEIGHTS, '--shard-id', str(SHARD_ID), '--num-shards', str(NUM_SHARDS),
       '--targets', *TARGETS, '--out', str(OUTPUT / f'{KIND}_{SCENARIO}_shard{SHARD_ID}')]
subprocess.check_call(cmd)
'''
    description='''# Revised finite-grid simulation reruns
This notebook embeds the source and runs independently. The bounded design has analytic truth and diagram-valued outcomes; functional, topological, ORBIT and PACCE alternatives are available in the selector. It uses iid covariates, independent folds, Gaussian unstudentized confidence calibration on the fixed evaluation grid, plain-tent topology units, training-fixed constant modulation, exact or explicitly learned ratios, and target-matched draws. Confidence and prediction default to 90% and 95%, respectively. Clinical data are not embedded. Shards checkpoint after every replication, count oracle construction toward the wall-clock budget, stop submitting new batches near that budget, and preserve failures. Already running oracle construction or a replication cannot be interrupted safely and may extend the budget. Profile a smoke run before a long topology shard and leave time for ZIP download. Oracle defaults are pilot sizes, and their recorded standard errors must be checked before reporting coverage. Results from smoke runs are not coverage evidence.
'''
    notebook("01_simulation_shard.ipynb",description,[cell(setup),cell(resume),cell(control),cell(download)])
    upload='''# Upload ONLY the released demo/lesion SAS files, or set FIXTURE=True for smoke.
FIXTURE = False
if not FIXTURE:
    from google.colab import files
    uploaded = files.upload()
    SAS = WORK / 'sas_input'
    SAS.mkdir(exist_ok=True)
    for filename, content in uploaded.items():
        if Path(filename).name not in ('demo.sas7bdat', 'lesion.sas7bdat'):
            raise ValueError('Only demo.sas7bdat and lesion.sas7bdat are needed')
        (SAS / Path(filename).name).write_bytes(content)
'''
    real='''# Independent pilot representation, then observed-data analysis only.
# Repeated splits/basis sizes are sensitivity analyses on one release, not MC coverage.
SEED = 20261010
for basis in (3, 5, 9):
    cmd = [sys.executable, 'revision_20261010/rerun/pacce_reanalysis.py',
           '--seed', str(SEED), '--stage2-basis', str(basis), '--out', str(OUTPUT / f'basis{basis}')]
    cmd += ['--fixture'] if FIXTURE else ['--sas-dir', str(SAS)]
    subprocess.check_call(cmd)
'''
    notebook("02_pacce_selected_reanalysis.ipynb","# PACCE independent-pilot observed-cohort diagnostics\nNo raw clinical data are embedded. This is an adjusted observed-group analysis conditional on a pilot-frozen representation. It does not identify a causal effect after treatment-affected observation, validate individual-effect coverage, or establish robustness to arbitrary missing-not-at-random outcomes. Predictions are width/shape objects with learned selected-cohort ratios.\n",[cell(setup),cell(upload),cell(real),cell(download)])
    sars_upload='''# Upload a ZIP containing COVID/ and non-COVID/ image folders; no patient IDs assumed.
from google.colab import files
uploaded = files.upload()
IMAGES = WORK / 'ct_images'
IMAGES.mkdir(exist_ok=True)
for filename, content in uploaded.items():
    with zipfile.ZipFile(io.BytesIO(content)) as z:
        for item in z.infolist():
            target = (IMAGES / item.filename).resolve()
            if IMAGES.resolve() not in target.parents:
                raise ValueError('Unsafe image ZIP path')
        z.extractall(IMAGES)
'''
    sars='''# Empirical slice-pool target; NOT a patient-level trial. Each account is independent.
SHARD_ID, NUM_SHARDS = 0, 1  # Use multiple shards only if preprocessing plus fitting is long.
R, REPS = 1, 200
pool = OUTPUT / 'sars_plain_pools.npz'
subprocess.check_call([sys.executable, 'revision_20261010/rerun/prepare_sars.py', '--data-root', str(IMAGES), '--r', str(R), '--out', str(pool)])
subprocess.check_call([sys.executable, 'revision_20261010/rerun/revised_experiments.py', '--kind', 'sars', '--pool', str(pool), '--r', str(R), '--n', '400', '--reps', str(REPS), '--workers', '2', '--hours', '8.5', '--shard-id', str(SHARD_ID), '--num-shards', str(NUM_SHARDS), '--out', str(OUTPUT / f'sars_shard{SHARD_ID}')])
'''
    notebook("03_sars_slice_rerun.ipynb","# SARS slice-pool rerun at r >= 1\nStreaming preprocessing preserves available image dimensions, uses first channel /255, finite H0 lower-star bars, and plain tents. There are no patient-level causal claims; both synthetic paired outcomes are retained and scored. Preprocessing can take substantial time, so first use a capped image smoke run locally.\n",[cell(setup),cell(sars_upload),cell(sars),cell(download)])
    print("Generated 3 self-contained notebooks and source ZIP")

if __name__=="__main__":main()
