"""Deterministic checks for changes essential to the revised experiments."""
import json
from pathlib import Path
import numpy as np
from revised_experiments import KnownPropensity,conformal_events,generate,draw_target
from tcda_uq.silhouette import compute_silhouette

def main():
    config=dict(kind="functional",scenario="base",degrees=2,resolution=20,scale=4,r=3,weights="known",alpha_prediction=.05)
    X,A,po,pi,t=generate(config,3000,123)
    Xt,ptot,pit,_=draw_target(config,3000,124,"overlap")
    assert (pi>=.01).all() and (pi<=.99).all()
    assert np.mean(pit*(1-pit))>np.mean(pi*(1-pi))
    # Treatment-affected observation can create a selected contrast under a
    # sharp causal null: U~Bernoulli(1/2), Y0=Y1=U, R0=1, R1=U.
    selected_difference=1-.5
    assert selected_difference==.5
    # An empty calibration arm must yield infinite composed bands.
    sample=(po[:8,0],np.zeros(8,dtype=int),X[:8])
    events=conformal_events(sample,config,"full",(X[8:18],po[8:18],pi[8:18],t),432)
    assert all(row["unbounded_fraction"]==1 for row in events)
    # GUDHI 3.11 normalizes the single tent by sqrt(2).
    diagram=np.array([[0.,1.]])
    values=np.asarray(compute_silhouette([diagram],interval=(0,1),r=3,resolution=11))[0]
    grid=np.linspace(0,1,11)
    tent=np.maximum(.5-np.abs(grid-.5),0)
    assert np.allclose(values/np.sqrt(2),tent)
    output={"known_DGP_positivity":True,"target_match_overlap":True,"empty_calibration_infinite":True,
            "plain_tent_rescaling":True,"selection_null_witness":selected_difference,
            "scope":"deterministic semantic tests; not a statistical coverage study"}
    path=Path(__file__).parent/"smoke/semantic_checks.json"
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(output,indent=2)+"\n")
    print(json.dumps(output,indent=2))

if __name__=="__main__":main()
