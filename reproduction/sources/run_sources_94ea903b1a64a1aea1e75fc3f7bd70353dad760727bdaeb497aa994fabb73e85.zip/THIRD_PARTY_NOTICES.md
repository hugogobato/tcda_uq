# Third-Party Notices

This repository contains original `tcda_uq` Python code plus research
reproduction material. Unless a file or directory says otherwise, the original
`tcda_uq` code is released under the MIT license in `LICENSE`.

## TATE Reference Code

Directory: `top-causal-effect-main/`

This directory is a local copy of the reference material used to reproduce the
TATE point-estimation pipeline and to document compatibility with the original
notebooks. The `tcda_uq` package ports the pieces it needs into Python modules
under `tcda_uq/`; the package wheel does not install `top-causal-effect-main/`.
The directory is ignored by default in `.gitignore`.

Before a public release, confirm the upstream license for this directory. If no
license is available, either remove it from the public repository or obtain
explicit permission from the upstream authors.

## FFSCB

Directory: `ffscb-master/`

The optional Liebl-Reimherr R backend uses source files from the `ffscb` package:

- Package: `ffscb`
- Authors: Dominik Liebl and Matthew Reimherr
- License: GPL (>= 3), as stated in `ffscb-master/DESCRIPTION`

The Python package includes a NumPy fallback for the Liebl-Reimherr band. The R
source is ignored by default and is not installed into the `tcda_uq` wheel or
source distribution. To use the faithful R-backed route, install or clone FFSCB
separately and set `FFSCB_R_DIR` to its `R/` directory. If you deliberately
redistribute `ffscb-master/`, keep the FFSCB license files and this notice with
it.

## External Data

Datasets are not bundled:

- ORBIT data are generated locally by the scripts.
- SARS-CoV-2 CT data are downloaded through Kaggle via the optional `[data]`
  extra.
- GEOM-Drugs data are not included and require `val_data.pickle`.
